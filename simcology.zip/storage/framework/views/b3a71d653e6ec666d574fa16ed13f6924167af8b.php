<?php $__env->startSection('content'); ?>

<section class="main-bg">
	<div class="inner-wrap-main">
		<div class="ems-left">
			<div class="ems-logo">
				<a href="<?php echo e(route('home')); ?>"><img src=" <?php echo e(asset('images/ems-logo.png')); ?> " /></a>
			</div>
			<div class="nav nav-tabs" id="nav-tab" role="tablist">
				<button class="nav-link btn-custom active" id="nav-introduction" data-toggle="tab" data-target="#nav-introduction-txt" type="button"><i class="bi bi-grid"></i> Introduction</button>
				<button class="nav-link btn-custom" id="nav-instructions" data-toggle="tab" data-target="#nav-instructions-txt" type="button"><i class="bi bi-bar-chart"></i> Instructions</button>
				<button class="nav-link btn-custom" id="nav-experiment" data-toggle="tab" data-target="#nav-experiment-txt" type="button"><i class="bi bi-chat"></i> Experiment</button>
				<button class="nav-link btn-custom" id="nav-observations" data-toggle="tab" data-target="#nav-observations-txt" type="button"><i class="bi bi-gear"></i> Observations</button>
			</div>
			<div class="ems-left-bottom">
				<div class="ems-btm-bg">
					<h3>Support 24/7</h3>
					<h4>Contacts us anytime</h4>
					<a href="#" class="btn btn-primary mt-3">start</a>
					<img src="<?php echo e(asset('images/mask-group.png')); ?>" />
				</div>
			</div>
		</div>
		<div class="tab-content ems-right" id="nav-tabContent">

			<div class="tab-pane fade show active" id="nav-introduction-txt" role="tabpanel" aria-labelledby="nav-introduction">
				<div class="main-tab-txt">
					<div class="main-title d-flex align-items-center pb-3">
						<h2>Introduction</h2>
						<a href="#" class="btn btn-primary ml-auto"><i class="bi bi-person"></i></a>
					</div>
					<h3 class="h3 pb-4">Study of diuretic activity using metabolic cage</h3>
					<div class="ems-box">
						<div class="ems-box-img">
							<img src="<?php echo e(asset('images/actophotometer--.jpg')); ?>" alt="" class="img-fluid"/>
						</div>
						<div class="ems-box-text">
							<p class="text-white">
							The metabolic cage is designed to allow measurement of fluid intake, and to separate and collect feces and urine for numerous qualitative and quantitative determinations. In addition, the metabolic cage permits observation of the animal, feces, and urine at all times.							</p>
						</div>
					</div>
				</div>
				
				<div class="pt-3 d-flex">
					<a href="#" class="btn btn-primary glb-btn ml-auto">Next Step: Observations</a>
				</div>
			</div>

			<div class="tab-pane fade" id="nav-instructions-txt" role="tabpanel" aria-labelledby="nav-instructions">
				<div class="main-tab-txt">
					<div class="main-title d-flex align-items-center pb-3">
						<h2>Instructions</h2>
						<a href="#" class="btn btn-primary ml-auto"><i class="bi bi-person"></i></a>
					</div>
					<div class="ems-box-white instruction-list">
						<ul class="list-unstyled">
							<li><i class="bi bi-hand-thumbs-up pr-4"></i> Divide animals into two groups (6 animals in each)</li>
							<li><i class="bi bi-hand-thumbs-up pr-4"></i> Administer one group with the drug (Furosemide 10mg/kg) to be tested and other with vehicle by oral route.</li>
							<li><i class="bi bi-hand-thumbs-up pr-4"></i> After that place the animals in metabolic cages.</li>
							<li><i class="bi bi-hand-thumbs-up pr-4"></i> Record the total volume of urine collected after 5 hr.</li>
							<li><i class="bi bi-hand-thumbs-up pr-4"></i> Compare the urine output between vehicle treated and drug treated group.</li>
						</ul>
					</div>
				</div>
				<div class="pt-3 d-flex">
					<a href="#" class="btn btn-primary glb-btn">Previous Step: Instructions</a>
					<a href="#" class="btn btn-primary glb-btn ml-auto">Next Step: Observations</a>
				</div>
			</div>

			<div class="tab-pane fade" id="nav-experiment-txt" role="tabpanel" aria-labelledby="nav-experiment">
				<div class="main-tab-txt">
					<div class="main-title d-flex align-items-center pb-3">
						<h2>Experiment</h2>
						<a href="#" class="btn btn-primary ml-auto"><i class="bi bi-person"></i></a>
					</div>
					
					<div class="row align-items-end">
						<div class="col-md-6">
							<div class="boxes">
								<h3>Vehicle Treated</h3>
								<div class="box-grp">
									<div class="tray-box">
										<img src="<?php echo e(asset('images/tray.png')); ?>" class="img-fluid"/>
										<ul>
											<li><img id="rat1" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="1" ratNumber="1" class="tray-rat" /></li>
											<li><img id="rat2" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="1" ratNumber="2" class="tray-rat" /></li>
											<li><img id="rat3" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="1" ratNumber="3" class="tray-rat" /></li>
											<li><img id="rat4" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="1" ratNumber="4" class="tray-rat" /></li>
											<li><img id="rat5" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="1" ratNumber="5" class="tray-rat" /></li>
											<li><img id="rat6" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="1" ratNumber="6" class="tray-rat"/></li>

										</ul>
									</div>
									<div class="tube-box">
										<img src="<?php echo e(asset('images/tube.png')); ?>" class="img-fluid" />
										<p>Vehicle</p>
									</div>
								</div>
							</div>
							<div class="boxes mt-4">
								<h3>Drug Treated</h3>
								<div class="box-grp">
									<div class="tray-box">
										<img src="<?php echo e(asset('images/tray.png')); ?>" class="img-fluid"/>
										<ul>
											<li><img id="rat1" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="2" ratNumber="1" class="tray-rat" /></li>
											<li><img id="rat2" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="2" ratNumber="2" class="tray-rat" /></li>
											<li><img id="rat3" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="2" ratNumber="3" class="tray-rat" /></li>
											<li><img id="rat4" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="2" ratNumber="4" class="tray-rat" /></li>
											<li><img id="rat5" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="2" ratNumber="5" class="tray-rat" /></li>
											<li><img id="rat6" src="<?php echo e(asset('images/rats/rat-1.png')); ?>" class="img-fluid tray-rat" ratType="2" ratNumber="6" class="tray-rat" /></li>
										</ul>
									</div>
									<div class="tube-box">
										<img src="<?php echo e(asset('images/tube.png')); ?>" class="img-fluid" />
										<p>Vehicle</p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 video-box-bg">
							<div class="video-box">
								<video id="video1" width="250" height="250" controls="" muted="">
									<source src="<?php echo e(asset('images/experiment_3/oral.mp4')); ?>" id="video2" type="video/mp4">
								</video>
							</div>
							<div class="video-text">
								<p class="m-0">Counter = <span id="counter-span"></span> </p>
							</div>
							<div class="table-responsive">
								<table class="table table-bordered text-center m-0">
									<thead>
										<tr>
											<th>Group Selected</th>
											<th>Locomotor Index</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>Vehicle</td>	
											<td class="d-flex"><input id="input-b" style="width:50%" type="text" class="form-control">
										        <button class="ml-3 btn btn-sm btn-primary" onclick="saveReading()" id="submit-reading">Submit</button>
										    </td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				
				<div class="pt-3 d-flex">
					<a href="#" class="btn btn-primary glb-btn">Previous Step: Instructions</a>
					<a href="#" class="btn btn-primary glb-btn ml-auto">Next Step: Observations</a>
				</div>
			</div>

			<div class="tab-pane fade" id="nav-observations-txt" role="tabpanel" aria-labelledby="nav-observations">
				<div class="main-tab-txt">

				    <div class="table pt-5 pb-4 ml-4 mr-5">
						
						<h3>Ovservation</h3>
						<table class="table table-bordered text-center">
							<thead>
								<tr>
									<th >Vehicle Treated</th>
									<th >Drug Treated</th>
								</tr>
							</thead>
							<tbody>
							
							<tr>
								<td></td>	
								<td></td>
							</tr>
							<tr>
								<td></td>	
								<td></td>
							</tr>
							<tr>
								<td></td>	
								<td></td>
							</tr><tr>
								<td></td>	
								<td></td>
							</tr>
							
							<tr>
								<td></td>	
								<td></td>
							</tr>
							
							<tr>
								<td></td>	
								<td></td>
							</tr>
							
							<tr>
								<td></td>	
								<td></td>
								<td></td>
							</tr>

							
							
							</tbody>
						</table>
						<!-- <div class="text-right pt-5">
							
							<a href="#" class="btn btn-custom mr-2" id="back2">Back to Experiment</a>
							<a href="#" class="btn btn-custom custom-2">Conclusion</a>
						</div> -->
					</div>


				</div>
				
				<div class="pt-3 d-flex">
					<a href="#" class="btn btn-primary glb-btn">Previous Step: Instructions</a>
				</div>
			</div>

		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>

<script>


</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jitendra/Documents/projects/emp-project/resources/views/experiments/apparatus_cage.blade.php ENDPATH**/ ?>