<?php $__env->startSection('content'); ?>

<section class="content" style="margin-top:79px !important;">
   <div class="container-fluid">
   <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Change Password</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-card-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
          <?php echo $__env->make('admin.layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(route('admin.save.password')); ?>" id="changePassword" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-md-6">
              <div class="form-group">
                                <input id="password" type="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="oldpassword"
                                        required autocomplete="current-password" placeholder="Old Password">
                            </div>
                            <div class="form-group">
                                <input  type="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="newPassword"
                                        required autocomplete="current-password" placeholder="New Password" id="newPassword">

                            </div>
                            <div class="form-group">
                                <input  type="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="confirmPassword"
                                        required autocomplete="current-password" placeholder="Re-Type Password" id="confirmPassword">
                                        <span id='notMatched' style='color:red'></span>
                                        <span id='Matched' style='color:green'></span>

                            </div>
                
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
              <div class="col-md-6">
                
                <!-- /.form-group -->
               
                <!-- /.form-group -->
              </div>
              <div class="col-md-6">
                  <button class="btn btn-primary" type="submit">Submit</button>
              </div>
              <!-- /.col -->
            </div>
            
            </form>

            <!-- /.row -->

            
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
         
        </div>
   </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
     <script>
          $("#changePassword").submit(function(event) {

                var newPassword     = $('#newPassword').val();
                var confirmPassword = $('#confirmPassword').val();

                if(newPassword == confirmPassword && newPassword !== '' && confirmPassword !== ''){
                    return true;
                }else{
                    document.getElementById('notMatched').innerHTML="Confirm Password Not  Matched";
                    return false ;
                }

          });
     
     </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jitendra/Documents/projects/emp-project/resources/views/admin/changePassword.blade.php ENDPATH**/ ?>