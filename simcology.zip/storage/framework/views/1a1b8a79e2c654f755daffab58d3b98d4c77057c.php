<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" class="btn btn-primary ml-auto"> <?php echo e(__('Logout')); ?></a>

					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form><?php /**PATH /home/jitendra/Documents/projects/emp-project/resources/views/layouts/logout.blade.php ENDPATH**/ ?>