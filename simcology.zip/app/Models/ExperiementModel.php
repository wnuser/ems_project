<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExperiementModel extends Model
{
    //
    protected $table = 'experiments';
}
