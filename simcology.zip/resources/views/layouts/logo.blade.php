<a href="{{ route('home') }}"><img style="width:160px; height:85px;" src="{{ asset('images/ems-blue-logo2.png') }}" /></a>
